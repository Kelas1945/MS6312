from tkinter import *
from tkinter.ttk import Combobox
from tkinter import filedialog as fd
import serial
from port import serial_ports,speeds
import time
from time import sleep
from PIL import Image, ImageDraw

portActiv=False

def PPort(kk):
    b6 = bytes(chr(kk), 'utf-8')
    realport.write(b6)
    ss=' '
    while ss!='W':
        ss=str(realport.readline())
        ss=ss[2:-5]                 

    
def img(): #печать картинки

    global realport
    global portActiv
    global stroki
    q=True
     
    file_name = fd.askopenfilename(filetypes=(("All files", "*.*"),("картинки", "*.jpg")))
    
    if file_name!="":
        pilImage = Image.open(file_name)
        draw = ImageDraw.Draw(pilImage)
        width = pilImage.size[0]  
        height = pilImage.size[1]  	
        pix0 = pilImage.load()

#преобразование картинки в чернобелую (2 цвета без оттенков серого)
        for i in range(width):
            for j in range(height):
                if i<width-1:
                    a = pix0[i, j][0]
                    b = pix0[i, j][1]
                    c = pix0[i, j][2]
                    S = (a + b + c) // 3
                    a = pix0[i+1, j][0]
                    b = pix0[i+1, j][1]
                    c = pix0[i+1, j][2]
                    S2 = (a + b + c) // 3                
                    if S>169:
                        S=255
                    if S<86:
                        S=0
                    
                    if (S>85)&(S<170)&(S2>85)&(S2<170):
                        q=~q
                        if q==True:
                            S=255
                            draw.point((i+1, j), (0, 0, 0))
                        else:
                            S=0
                            draw.point((i+1, j), (255, 255, 255))
                            
                    draw.point((i, j), (S, S, S))

        pilImage.save("wb\swb.png", "PNG")

        pilImage.show() #Открывает в новом окне, расширение изображения меняется на PNG

        height2=(height//6)*6 #приводим высоту картинки кратной 6 (отсекая лишние строки картинки)

        width2=width//256
        width1=width - (width2*256)

        b6 = bytes(chr(27), 'utf-8') #Esc
        realport.write(b6)
        
        PPort(51) #интервал между строк
        PPort(18) #равен 18/216 дюймового интервала
            
        for j in range(0, height2, 6):
            PPort(10) # продвинуть лист
            PPort(13) # возврат каретки
            #переводим принтер в графический режим            
            PPort(27) #Esc
            PPort(42) #графический режим
            PPort(5)  #№5
            PPort(width1) #количество графических данных
            PPort(width2) #количество графических данных           
            
            for i in range(width):
                p=0
                a = pix0[i, j][0]
                if a==0:
                    p=32
                else:
                    p=0

                a = pix0[i, j+1][0]
                if a==0:
                    p=p+16
                else:
                    p=p+0

                a = pix0[i, j+2][0]
                if a==0:
                    p=p+8
                else:
                    p=p+0                
                
                a = pix0[i, j+3][0]
                if a==0:
                    p=p+4
                else:
                    p=p+0
            
                a = pix0[i, j+4][0]
                if a==0:
                    p=p+2
                else:
                    p=p+0

                a = pix0[i, j+5][0]
                if a==0:
                    p=p+1
                else:
                    p=p+0
                
                PPort(p) #отправляем столбик точек в количестве 6 строк
                
                
def clicked():
    global realport
    global portActiv        
    try:
        realport = serial.Serial(combo.get(),int(combo2.get()))
        
        if realport.port.find("COM")==0:
            portActiv=True
            time.sleep(2)
            btn.configure (text="Подключено", bg="green", fg="blue")
            
    except Exception as e:
        print(e)


        
def info():
    messagebox.showinfo('Информация', 'Программа для печати на струйном принтере Электроника МС-6312.\ncpurus@yandex.ru      февраль 2023')

  
    
    
## ----------------------------------------------------------------------------------------------
root = Tk()
root.iconbitmap(r'img\logo.ico')
root.title("Электроника МС6312")  

frame1=Frame(root, bd=1, relief=RAISED)
frame1.pack(side=TOP, fill=X)

mainmenu = Menu(frame1) 
root.config(menu=mainmenu)

mainmenu.add_cascade(label="Картинка", command=img)
mainmenu.add_cascade(label="Справка", command=info)

lbl = Label(frame1, text="Порт", font=("Arial Bold", 10))  
lbl.grid(column=0, row=0)

combo = Combobox(frame1, width=7)
combo['values'] = (serial_ports())
combo.grid(column=1, row=0)    

#IndexError
try:
    combo.current(0)
except:
    print ("Хо")
    
lb2 = Label(frame1, text="Скорость", font=("Arial Bold", 10))  
lb2.grid(column=0, row=1)

combo2 = Combobox(frame1, width=7)  
combo2['values'] = (speeds)  
combo2.current(7)  # установите вариант по умолчанию  
combo2.grid(column=1, row=1)

btn = Button(frame1, text="Подключиться", command=clicked)  
btn.grid(column=2, row=0)

## ******************создаем окно программы нужного размера****************************************
root.update_idletasks()
s = root.geometry()
s = s.split('+')
s = s[0].split('x')
width_root = int(s[0])
height_root = int(s[1])
 
w = root.winfo_screenwidth()
h = root.winfo_screenheight()
w = w // 2
h = h // 2 
w = w - width_root // 2
h = h - height_root // 2 -50
root.geometry('+{}+{}'.format(w, h))

root.mainloop()
